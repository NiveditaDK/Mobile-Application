package com.cs442.team11.tictactoe;

/**
 * Created by nivedita.kalele on 12/10/2015.
 */
public class GlobalData {
    public static int Width;
    public static int Height;
    public static int getWidth() {
        return Width;
    }
    public static void setWidth(int width) {
        Width = width;
    }
    public static int getHeight() {
        return Height;
    }
    public static void setHeight(int height) {
        Height = height;
    }

}
